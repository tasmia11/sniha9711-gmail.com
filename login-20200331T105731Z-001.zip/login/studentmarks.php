<?php
      $con=mysqli_connect('localhost','root','');
      mysqli_select_db($con,'loginInfo');
     	
     if(isset($_POST['classsub'])){
     	if ($_POST['classtype']==0) {
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id";		
      	}
      	else{
      		$classtype=$_POST['classtype'];	
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id where subject.class_id='$classtype'";
      	}
      	
      }
      else if(isset($_POST['secsub'])){
      	if ($_POST['sectype']==0) {
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id";		
      	}
      	else{
      		$sectype=$_POST['sectype'];
      		if($sectype==1){
      			$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id where subject.section='A'";
      		}
      		else if($sectype==2){
      			$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id where subject.section='B'";	
      		}
      		
      	}
      }
      else if(isset($_POST['subsub'])){
      	if ($_POST['subtype']==0) {
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id";		
      	}
      	else if ($_POST['subtype']==1) {
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id where subject.sub_name='English'";	
      		
      	}
      	else if ($_POST['subtype']==2) {
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id where subject.sub_name='Mathematics'";	
      		
      	}
      	else if ($_POST['subtype']==3) {
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id where subject.sub_name='Arts'";	
      		
      	}
      	else if ($_POST['subtype']==4) {
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id where subject.sub_name='Science'";	
      		
      	}
      	else if ($_POST['subtype']==5) {
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id where subject.sub_name='Geography'";	
      		
      	}
      }
      else if(isset($_POST['searcheng'])){
      	if (empty($_POST['searcheng'])) {
      		$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id";		
      	}
      	else{
	      	$s=$_POST['searcheng'];
	      	$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id where subject.teacher_name like '%$s%' || student.name like '%$s%' || subject.student_id like '%$s%'";	
      	}	
      	
      }
     else{
      	$q="SELECT subject.student_id, student.name, subject.class_id, subject.section, subject.sub_name, subject.sub_marks, subject.teacher_name from student inner join subject on subject.student_id=student.id";		
      }
      $result=mysqli_query($con,$q);

?>
<!DOCTYPE html>
<html>
<head>
<script type='text/javascript'
  src='http://code.jquery.com/jquery-2.0.2.js'></script>
<link rel="stylesheet" type="text/css"
  href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
<script type='text/javascript'
  src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css"
  href="http://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/studentmarks.css">

</head>
<body>
	<form action="studentmarks.php" method="POST">
  <div class="Table">
  	<div class="search">
    <input type="text" name="searcheng" class="searchTerm" placeholder="What are you looking for?">
    <button type="submit" class="searchButton">
      <i class="fa fa-search"></i>
   	</button>
 	</div>
    <table id="myTable" class="table table-hover">
      
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>
            <div class="dropdown">
    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Class
    <span class="caret"></span></button>
    <div class="dropdown-menu">
    	<select name="classtype">
      <option value=0>...</option></li>
      <option value=1>Class I</option></li>
      <option value=2>Class II</option></li>
      <option value=3>Class III</option></li>
      <option value=4>Class IV</option></li>
      <option value=5>Class V</option></li>
  </select>
    </div>

    <input name="classsub" type="submit" value="Submit">
  </div>

            </th>
            <th>
              <div class="dropdown">
              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Section
              <span class="caret"></span></button>
              <div class="dropdown-menu">
              <select name="sectype">
              <option value=0>...</option></li>
              <option value=1>A</option></li>
              <option value=2>B</option></li>
          	  </select>
          	</div>

			<input name="secsub" type="submit" value="Submit">
              </div>
              </th>
          <th>
            <div class="dropdown">
          <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">  Subject
          <span class="caret"></span></button>
          <div class="dropdown-menu">
          	<select name="subtype">
          	<option value=0>...</option></li>
        	<option value=1>English</option></li>
          	<option value=2>Mathematics</option></li>
          	<option value=3>Arts</option></li>
          	<option value=4>Science</option></li>
         	<option value=5>Geography</option></li>
      	</select>
  		</div>

      	<input name="subsub" type="submit" value="Submit">
          </div>
          </th>
          <th>Marks</th>
          <th>Teacher</th>
          <?php
          	if($result!=false){
              while($rows=mysqli_fetch_assoc($result)){
            ?>
            <tr>
            <td><?php echo $rows['student_id']?></td>
            <td><?php echo $rows['name']?></td>
            <td><?php echo $rows['class_id']?></td>
            <td><?php echo $rows['section']?></td>
            <td><?php echo $rows['sub_name']?></td>
            <td><?php echo $rows['sub_marks']?></td>
            <td><?php echo $rows['teacher_name']?></td>
            </tr>
            <?php
              }
          }
            ?>
      </thead>
  </div>

    <tbody>



    </tbody>
  </table>


  <div class="wrap">
 
</div>
</body>
</html>
