<?php
      $con=mysqli_connect('localhost','root','');
      mysqli_select_db($con,'loginInfo');
     	
     if(isset($_POST['classsub'])){
      if ($_POST['classtype']==0) {
          $q="select*from student";   
        }
        else{
          $classtype=$_POST['classtype']; 
          $q="select*from student where class_id='$classtype'";
        }
        
      }
     
      else if(isset($_POST['searcheng'])){
        if (empty($_POST['searcheng'])) {
          $q="select*from student";   
        }
        else{
          $s=$_POST['searcheng'];
          $q="select*from student where id like '%$s%' || name like '%$s%' || admin_id like '%$s%' || address like '%$s%' || f_name like '%$s%' || m_name like '%$s%' || contact like '%$s%'";
        } 
        
      }
     else{
        $q="select*from student";   
      }
      $result=mysqli_query($con,$q);
?>



<!DOCTYPE html>
<html>
<head>
<script type='text/javascript'
  src='http://code.jquery.com/jquery-2.0.2.js'></script>
<link rel="stylesheet" type="text/css"
  href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
<script type='text/javascript'
  src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css"
  href="http://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/studentmarks.css">

</head>
<body>
	<form action="studentinfo.php" method="POST">
  <div class="Table">
  	<div class="search">
    <input type="text" name="searcheng" class="searchTerm" placeholder="What are you looking for?">
    <button type="submit" class="searchButton">
      <i class="fa fa-search"></i>
   	</button>
 	</div>
    <table id="myTable" class="table table-hover">
      
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>
            <div class="dropdown">
    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Class
    <span class="caret"></span></button>
    <div class="dropdown-menu">
    	<select name="classtype">
      <option value=0>...</option></li>
      <option value=1>Class I</option></li>
      <option value=2>Class II</option></li>
      <option value=3>Class III</option></li>
      <option value=4>Class IV</option></li>
      <option value=5>Class V</option></li>
  </select>
    </div>

    <input name="classsub" type="submit" value="Submit">
  </div>

          <th>Gender</th>
          <th> Address </th>
          <th> Father's Name </th>
          <th> Mother's Name </th>
          <th> Admin ID </th>
          <th> Contact </th>
          <?php
          	if($result!=false){
              while($rows=mysqli_fetch_assoc($result)){
            ?>
            <tr>
            <td><?php echo $rows['id']?></td>
            <td><?php echo $rows['name']?></td>
            <td><?php echo $rows['class_id']?></td>
            <td><?php echo $rows['gender']?></td>
            <td><?php echo $rows['address']?></td>
            <td><?php echo $rows['f_name']?></td>
            <td><?php echo $rows['m_name']?></td>
            <td><?php echo $rows['admin_id']?></td>
            <td><?php echo $rows['contact']?></td>
            </tr>
            <?php
              }
          }
            ?>
      </thead>
  </div>

    <tbody>



    </tbody>
  </table>


  <div class="wrap">
 
</div>
</body>
</html>
