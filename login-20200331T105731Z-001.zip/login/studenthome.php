<?php
session_start();
?>


<html>
<head>
	<title> Home </title>
</head>
<body>
	<div class="container">
			<button onclick="goBack()">Go Back</button>
			<script>
				function goBack() {
				  window.history.back();
			}
			</script>
			<h1> Welcome <?php echo $_SESSION['user']; ?> </h1>
			<a href="studentinfo.php"> Show Student Database </a>
			<p></p>
			<a href="studentmarks.php"> Show Student Marks </a>
	</div>
</body>
</html>