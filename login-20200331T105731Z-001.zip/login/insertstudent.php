<?php 
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con, 'logininfo');
if(!$con){
	die(mysqli_error($con));
}
$id=$_POST['id'];
$name=$_POST['name'];
$class=$_POST['class_id'];
$gender=$_POST['gender'];
$address=$_POST['address'];
$fname=$_POST['f_name'];
$mname=$_POST['m_name'];
$admin=$_POST['adminid'];
$contact=$_POST['contact'];
$q="INSERT INTO student (`id`, `name`, `class_id`, `gender`, `address`, `f_name`, `m_name`, `admin_id`, `contact`) VALUES ('$id', '$name', '$class', '$gender', '$address', '$fname', '$mname', '$admin', '$contact')";
$sql="INSERT INTO userinfo (`username`, `password`, `usertype`) VALUES ('$name', '$id', 'student')";
if(!mysqli_query($con, $q)){
	die(mysqli_error($con));
}
if(!mysqli_query($con, $sql)){
	die(mysqli_error($con));
}
header('location:student.html');
?>
