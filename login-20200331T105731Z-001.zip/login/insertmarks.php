<?php 
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con, 'logininfo');
if(!$con){
	die(mysqli_error($con));
}
$id=$_POST['id'];
$class=$_POST['class'];
$section=$_POST['section'];
$sub_name=$_POST['sub_name'];
$sub_marks=$_POST['sub_marks'];
$teacher_name=$_POST['teacher_name'];

$q="INSERT INTO subject (`student_id`, `class_id`, `section`, `sub_name`, `sub_marks`, `teacher_name`) VALUES ('$id', '$name', '$class', '$section', '$sub_name', '$sub_marks', '$teacher_name')";
if(!mysqli_query($con, $q)){
	die(mysqli_error($con));
}
header('location:newStudentMarks.html');
?>
