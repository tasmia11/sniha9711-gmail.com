<?php
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'loginInfo');
if(isset($_POST['searcheng'])){
      	if (empty($_POST['searcheng'])) {
      		$q="select*from teacher";		
      	}
      	else{
	      	$s=$_POST['searcheng'];
	      	$q="select*from teacher where id like '%$s%' || name like '%$s%' || address like '%$s%' || contact like '%$s%'";	
      	}	
      	
}
else{
      	$q="select*from teacher";		
      }
      $result=mysqli_query($con,$q);
?>
<!DOCTYPE html>
<html>
<head>
<script type='text/javascript'
  src='http://code.jquery.com/jquery-2.0.2.js'></script>
<link rel="stylesheet" type="text/css"
  href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
<script type='text/javascript'
  src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css"
  href="http://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/studentmarks.css">

</head>
<body>
	<form action="teacherinfo.php" method="POST">
  <div class="Table">
  	<div class="search">
    <input type="text" name="searcheng" class="searchTerm" placeholder="What are you looking for?">
    <button type="submit" class="searchButton">
      <i class="fa fa-search"></i>
   	</button>
 	</div>
    <table id="myTable" class="table table-hover">
      
    <thead>
	<th> ID </th> 
	<th> Name </th>
	<th> Gender </th>
	<th> Address </th>
	<th> Contact </th>
	<?php
		while($rows=mysqli_fetch_assoc($result)){
	?>
	<tr>
	<td><?php echo $rows['id']?></td>
	<td><?php echo $rows['name']?></td>
	<td><?php echo $rows['gender']?></td>
	<td><?php echo $rows['address']?></td>
	<td><?php echo $rows['contact']?></td>
	</tr>
	<?php
		}
	?>
	</table>
</body>
</html>
