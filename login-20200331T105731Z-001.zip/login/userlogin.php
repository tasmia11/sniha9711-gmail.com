<?php

session_start();
$con=mysqli_connect('localhost','root','');
if(!$con){
	die(mysqli_error($con));
}
mysqli_select_db($con,'loginInfo');
$user=$_POST['user'];
$pass=$_POST['pass'];
$usertype=$_POST['usertype'];
$q="select*from userinfo where username='$user' && password='$pass' && usertype='$usertype'";
$result=mysqli_query($con,$q);
$num=mysqli_num_rows($result);

if($num==1){
	$_SESSION['user']=$user;
	if($usertype=="student"){
		header('location:studentmarks.php');
	}
	else if($usertype=="teacher"){
		header('location:teacherhome.html');
	}
	else if($usertype=="admin"){
		header('location:admin.html');
	}
	
}
else{
	header('location:userlogin.php');
}
?>