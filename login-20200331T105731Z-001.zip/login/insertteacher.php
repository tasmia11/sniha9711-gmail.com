<?php 
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con, 'logininfo');
if(!$con){
	die(mysqli_error($con));
}
$id=$_POST['id'];
$name=$_POST['name'];
$gender=$_POST['gender'];
$contact=$_POST['contact'];
$address=$_POST['address'];

$q="INSERT INTO teacher (`id`, `name`, `gender`, `contact`, `address`) VALUES ('$id', '$name', '$gender', '$contact', '$address')";
$sql="INSERT INTO `userinfo` (`username`, `password`, `usertype`) VALUES ('$name', '$id', 'teacher')";
if(!mysqli_query($con, $q)){
	die(mysqli_error($con));
}
if(!mysqli_query($con, $sql)){
	die(mysqli_error($con));
}
header('location:teacher.html');
?>
